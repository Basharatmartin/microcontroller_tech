
// Name : Syed Sagheer Hussain  
// Exercise Nr. 5 
// Description : PWM 

#include "templateEMP.h"

// melodies and its frequencies 
#define  C4     3830    // 261 Hz	1915
#define  D4     3400    // 294 Hz	1700
#define  E4     3038    // 329 Hz	1519
#define  F4     2864    // 349 Hz	1432
#define  G4     2550    // 392 Hz	1275
#define  A4     2272    // 440 Hz	1136
#define  B4     2028    // 493 Hz	1014
#define  C5     1912    // 523 Hz	956
#define  B4b    2146	// 466 Hz	1073
#define  E5     1517	// 659 Hz	759

// Global variables ->> Tones 
unsigned int happy_birthday[25] = {C4, C4, D4, C4, F4, E4,C4, C4, D4, C4, G4, F4,C4, C4, C5, A4, F4, E4, D4,B4b, B4b, A4, F4, G4, F4};
unsigned int interval_hb[25] = {200, 200, 270, 270, 270, 670, 200, 200, 270, 270, 270, 590, 200, 200, 270, 270, 270, 300, 670,250, 250, 300, 300, 300, 590};

unsigned int random_tone[15] = {A4, B4, A4, B4b, A4, B4, B4, B4, B4, C5, B4, C5, B4, A4};
unsigned int interval_random[15] = {410, 210, 213, 410, 310, 210, 300, 310, 200, 200, 200, 100, 400, 100};

#define piezo_buzzer	BIT6	// connected to P3.6 
#define PB5		BIT3 	// connected to P1.3 button 
#define PB6		BIT4 	// connected to P1.4 button

void _delay(unsigned int ms);
void _first_melody(void);
void _second_melody(void);
void _init_timer(void);

unsigned int count=0;
unsigned short mode=0;
unsigned short once=1;
unsigned short melody=0;
unsigned short PB5_count=0;
unsigned short PB5_switch=0;
unsigned short PB6_switch=0;

int main(void) {

	initMSP();

	P3DIR |= piezo_buzzer;		// output to Buzzer
	P3SEL |= piezo_buzzer;		// P3.6 TA0.2 option
	TA0CCTL2 = OUTMOD_3;		// CCR2 set/reset
	TA0CTL = TASSEL_2 + MC_1;	// SMCLK: MC_1 -> Up mode;

	P1SEL  &= ~(PB5 + PB6); 	// enabling the buttons PB5 & PB6
	//P1SEL2 &= ~(PB5 + PB6);		
	P1DIR &= ~(PB5 + PB6);		// setting direction of the buttons as input
	P1REN |= (PB5 + PB6);		// enabling the pull-up resistors for buttons PB5 & PB6
	P1IE |= (PB5 + PB6);		// enabling the interrupt for Port 1 for Pins  P1.3 & P1.3
	P1IES |= (PB5 + PB6);		// trigger interrupt (falling edge) - High -> Low 
	P1IFG &= ~(PB5 + PB6);		// clearing the flag
	__enable_interrupt();		// enabling the interrupts

	for (;;)			// forever loop
	{
		if (melody==1){		// checking if 1 then play the melody_1();
			_first_melody();
		}
		if (melody==2){		// checking if 2 then play the melody_2();
			_second_melody();
		}
	}
}

void _delay(unsigned int ms)
{
	while (ms--){
        	__delay_cycles(1000);	// 1000 for 1 MHz
    	}
}


void _init_timer(void)
{
    TA1CCTL0  = CCIE;			// enabling Timer_A capture / compare interrupt 
    TA1CCR0   = 10000;			// PWM period
    TA1CTL  = TASSEL_2 + MC_1;		// SMCLK; MC_1 ->  up mode ;
}


void _first_melody(void)
{
	unsigned char i;
	for (i = 0; i < 25; i++)
	{
		do
		{
			TA0CCR0 = 0;
		}
		while(PB6_switch == 1);		// PB6 pause and replay _first_melody();
		if (melody != 1)		// play _first_melody(); as long as _first_melody(); flag is set
			break;

    		TA0CCR0 = happy_birthday[i];	// pwm period
    		TA0CCR2 = happy_birthday[i]/2;	// 50% duty cycle
    		_delay(interval_hb[i]);		// duration of tones
    		TA0CCR0 = 0;			// period 0 - no tones
    		_delay(100);			// no tones  duration
    	}
    	TA0CCR2 = 0;
}

void _second_melody(void)
{
	unsigned char i;
	for (i = 0; i < 16; i++)
	{
		do
		{
			TA0CCR0 = 0;
		}
		while(PB6_switch == 1);		// PB6 pause and replay _second_melody();
		if (melody != 2)		// play melody_2(); as long as _second_melody(); flag is set
			break;

    		TA0CCR0 = random_tone[i];	// pwm period
    		TA0CCR2 = random_tone[i]/2;	// 50% duty cycle
    		_delay(interval_random[i]);	// duration of tones
    		TA0CCR0 = 0;			// period 0 - no tones
    		_delay(100);			// no duration of tones
    	}
    	TA0CCR2 = 0;
}

// Timer A0 interrupt service routine
#pragma vector=TIMER1_A0_VECTOR
__interrupt void Timer_A (void)
{
	count++;				// increment count
	if (count == 100){			// if it is reached
		count = 0;			// reset to count
		PB5_count = 0;			// reset PB5 interrupt count
	}
}

// Port 1 interrupt vector
#pragma vector=PORT1_VECTOR
__interrupt void Port_1(void)
{
	if (P1IFG & PB5){			// PB5 nterrupt
		if (once == 1){			// only once - timer
			once = 2;		// lock up re-executing _init_timer();
			_init_timer();		// Initialization of timer
		}
		PB5_count++;			// counter increment
		P1IFG &= ~PB5;			// clear PB5 interrupt
		if (PB5_count == 1){		// checking if button pressed once 
			melody = 1;		// set _first_melody(); flag
			count = 0; 		// reset timer
		}
		if (PB5_count == 2){		// checking if button pressed two times
			melody = 2;		// set _second_melody(); flag
			count = 0;		// reset timer
		}
	}

	if (P1IFG & PB6){			// PB6 interrupt?
		P1IFG &= ~PB6;			// clear PB6 interrupt
		PB6_switch++;			// counter increment
		if (PB6_switch == 2)		// for pause and reply two  times it is needed
			PB6_switch = 0;
	}
}
